/**
 * 
 */
/**
 * @author QuatroQuatros
 *
 */
module FintechDAO {
	requires java.sql;
}